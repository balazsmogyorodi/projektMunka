def feladat5():


