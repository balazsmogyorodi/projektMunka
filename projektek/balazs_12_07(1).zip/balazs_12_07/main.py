import karacsonyFa
import vers


karacsonyFa.elso()
#vers.feladat4()