package mogyoródibalázs_kvíz;

import java.awt.HeadlessException;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class jatek {

    private static int KerdoSzam, pontszam, uzenet, lehetoseg, gomb, eredmeny, szamolas;
    private static String nev, cim, kerdes, feladat, valasztas, kijelolve, valasz, info, kiiras;
    private static boolean jatek;

    public static void main(String[] args) {

        TeljesProgram();
    }

    private static void TeljesProgram() throws HeadlessException {
        kezdoErtek();
        while (jatek != false) {
            TeljesJatek();
            
        }
    }

    private static void TeljesJatek() throws HeadlessException {
        while (3 > nev.length()) {
            nev = NevetKerek();
        }
        kerdesek();
        JatekmenetVege() ;
        JatekUjra();
    }

    private static void kezdoErtek() {
        nev = "";
        jatek = true;
    }

    private static void kerdesek() throws HeadlessException {
        kerdes1();
        kerdes2();
        kerdes3();
        kerdes4();
        kerdes5();
    }

    private static void JatekUjra() throws HeadlessException {
        kerdes = "Megpróbálod újra?";
        cim = "Újra";
        uzenet = JOptionPane.QUESTION_MESSAGE;
        lehetoseg = JOptionPane.YES_NO_OPTION;
        gomb = JOptionPane.showConfirmDialog(null, kerdes, cim, lehetoseg, uzenet);
        if (gomb == JOptionPane.YES_OPTION){
            jatek = true;
        }
        if (gomb == JOptionPane.NO_OPTION){
            jatek = false;
        }
    }

    private static void JatekmenetVege() throws HeadlessException {
        kiiras = "Gratulálok " + nev + ", az elért eredményedért: 5/" + pontszam ;
        cim = "Játék vége";
        uzenet = JOptionPane.INFORMATION_MESSAGE;
        JOptionPane.showMessageDialog(null, kiiras, cim, uzenet);
    }

    private static void kerdes1() throws HeadlessException {
        kiinduloKerdesSzam();
        kerdes = nev + ": Mennyi 5*5?";
        uzenet = JOptionPane.QUESTION_MESSAGE;
        szamolas = Integer.parseInt(JOptionPane.showInputDialog(null, kerdes, cim, uzenet));
        eredmeny = 25;
        valasz = "25";
        if (szamolas == eredmeny){
             valasztas = Jovalasz(valasztas, valasz);
        }
        else {
        RosszValasz(valasztas, valasz);      
        }
        
    
    }

    private static void kerdes2() throws HeadlessException {
        novekvoKerdoSzam();
        kerdes = nev + ": Milyen szímű az ég";
        uzenet = JOptionPane.QUESTION_MESSAGE;
        Icon kep = new ImageIcon("");
        String[] valaszok = {"piros", "sárga", "zöld", "kék"};
        valasz = "kék";
        kijelolve = "sárga";
        valasztas = (String) JOptionPane.showInputDialog(null, kerdes, cim, uzenet, kep, valaszok, kijelolve);
        ValaszEredmeny(valasztas, valasz);
    }

    private static void kerdes5() throws HeadlessException {
        novekvoKerdoSzam();
        kerdes = nev + ": 6*5=25";
        uzenet = JOptionPane.QUESTION_MESSAGE;
        lehetoseg = JOptionPane.YES_NO_OPTION;
        valasz = "nem";
        gomb = JOptionPane.showConfirmDialog(null, kerdes, cim, lehetoseg, uzenet);
        NoValasz();
    }

    private static void kerdes4() throws HeadlessException {
        // 4. kérdés
        novekvoKerdoSzam();
        kerdes = nev + ": 5*5=25";
        uzenet = JOptionPane.QUESTION_MESSAGE;
        valasz = "igen";
        gomb = JOptionPane.showConfirmDialog(null, kerdes, cim, lehetoseg, uzenet);
        YesValasz();
    }

    private static void kerdes3() throws HeadlessException {
        Icon kep;
        // 3. kérdés
        novekvoKerdoSzam();
        kerdes = nev + ": Mi a címe Akira Kuroszava világhírű filmjének: A hét_";
        uzenet = JOptionPane.QUESTION_MESSAGE;
        kep = new ImageIcon("");
        String[] valaszok2 = {"szamuráj", "kupleráj", "bonszáj", "szamovár"};
        valasz = "szamuráj";
        kijelolve = "bonszáj";
        valasztas = (String) JOptionPane.showInputDialog(null, kerdes, cim, uzenet, kep, valaszok2, kijelolve);
        ValaszEredmeny(valasztas, valasz);
    }

    private static void YesValasz() throws HeadlessException {
        if (gomb == JOptionPane.YES_OPTION) {
            valasztas = Jovalasz(valasztas, valasz);
        }
        if (gomb == JOptionPane.NO_OPTION) {
            RosszValasz(valasztas, valasz);
        }
    }

    private static void NoValasz() throws HeadlessException {
        if (gomb == JOptionPane.YES_OPTION) {
            RosszValasz(valasztas, valasz);
        }
        if (gomb == JOptionPane.NO_OPTION) {
            valasztas = Jovalasz(valasztas, valasz);
        }
    }

    

    

    private static void novekvoKerdoSzam() {
        KerdoSzam++;
        cim =  KerdoSzam + ". kérdés";
    }
     
    private static void kiinduloKerdesSzam() {
        pontszam = 0;
        KerdoSzam = 1;
        cim =  KerdoSzam + ". kérdés";
    }

    private static void ValaszEredmeny(String valasztas, String valasz) throws HeadlessException {
        if (valasztas == valasz) {
            valasztas = Jovalasz(valasztas, valasz);
        }
        if (valasztas != valasz) {
            RosszValasz(valasztas, valasz);
        }
    }

    private static void RosszValasz(String valasztas, String valasz) throws HeadlessException {
        info = "Nem jó, a helyes válasz: " + valasz;
        cim = "A választás eredménye";
        uzenet = JOptionPane.INFORMATION_MESSAGE;
        JOptionPane.showMessageDialog(null, info, cim, uzenet);
    }

    private static String Jovalasz(String valasztas, String valasz) throws HeadlessException {
        info = "Igen, a helyes válasz: " + valasz;
        cim = "A választás eredménye";
        uzenet = JOptionPane.INFORMATION_MESSAGE;
        JOptionPane.showMessageDialog(null, info, cim, uzenet);
        pontszam++;
        return valasztas;
    }

    private static String NevetKerek() throws HeadlessException {
        String nev;
        nev = JOptionPane.showInputDialog("Kérek egy nevet, minimum 3 betűs legyen!");
        return nev;
    }

}
