import metodus

def paros():
    szam = metodus.SzamErtek()
    if szam % 2 == 0:
        print(str(szam), "Ez a szám páros.")
    else:
        print(str(szam), "Ez a szám nem páros.")




