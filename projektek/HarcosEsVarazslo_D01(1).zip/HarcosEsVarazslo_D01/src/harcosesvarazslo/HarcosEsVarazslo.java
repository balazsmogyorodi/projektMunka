package harcosesvarazslo;

public class HarcosEsVarazslo {
    public static void main(String[] args) {
        String tab = "   ";
        int hElet = 9, vElet = 9;
        
        System.out.println("3 körös játék");
        
        System.out.println("KEZDÉS:");
        System.out.printf("%sH:%d V:%d\n", tab, hElet, vElet);
        
        for (int i = 0; i < 3; i++) {
            System.out.println((i+1) + ". kör");
            int hHely = (int)(Math.random()*3);
            int vHely = (int)(Math.random()*3);
            if(hHely == vHely){
                System.out.println(tab + "HARC:");
                int dobas = (int)(Math.random()*6)+1;
                hElet -= dobas;
                dobas = (int)(Math.random()*6)+1;
                vElet -= dobas;
            }else{
                System.out.println(tab + "KALANDOZÁS:");
            }
            System.out.printf("%sH:%d V:%d\n", tab, hElet, vElet);
        }
    }
    
}
