def elso():
    kiFajl = open("karacsony.txt","w", encoding="utf-8")
    db = 0
    sor = 1
    alap = 1
    terkoz = 0
    amig = int(input("hány szintes legyen a karácsonfa? "))
    valtozo = 0
    while db < amig:
        while terkoz < amig:
            kiFajl.write(" ")
            terkoz += 1
        while sor < alap:
            kiFajl.write("**")
            sor += 1
        db += 1
        alap += 1
        sor = 1
        kiFajl.write("*\n")
        valtozo += 1
        terkoz = valtozo

    terkoz = 0
    ag = amig
    while terkoz < amig:
        terkoz += 1
        kiFajl.write(" ")
    kiFajl.write("||")
    kiFajl.close()



    beFajl = open("karacsony.txt", "r", encoding="utf-8")
    adatok = beFajl.readlines()
    index = 0
    while index < len(adatok):
        print("\033[32;40m {:^{}}".format(adatok[index].strip(), amig*2))
        index += 1
    beFajl.close()








