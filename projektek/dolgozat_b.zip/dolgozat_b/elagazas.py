def elagazs():
    def feladatSzam():
        print("I/a.")

    def tabosito():
        tab = "     "
        print(tab, end="")


    def bekeres():
        elso = 100
        while elso > 99 or elso <= 0:
            tabosito()
            elso = int(input("Kérek egy pozitív egész számot (maximum 99): "))
        szamok.append(elso)
        masodik = 100
        while masodik > 99 or masodik <= 0:
            tabosito()
            masodik = int(input("Kérek egy másik pozitív egész számot (maximum 99): "))
        szamok.append(masodik)

    def nagyobb():
        if szamok[0] > szamok[1]:
            tabosito()
            print("Nagyob az első szám számjegyeinek összege, mint a második szám.")
        elif szamok[0] < szamok[1]:
            tabosito()
            print("Nagyob a második szám számjegyeinek összege, mint az első szám.")

    szamok = []
    feladatSzam()
    bekeres()
    nagyobb()





