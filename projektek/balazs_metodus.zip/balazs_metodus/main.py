import feladat1

feladat1.primszam()
#feladat2.paros()

