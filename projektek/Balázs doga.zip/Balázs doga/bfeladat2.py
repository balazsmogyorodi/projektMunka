def harmadikfor():
    szam = 1

    for szam in range(20, 160, 4):
        print(str(szam) + "_", end="")
    print(160)

def harmadikwhile():
    szam = 20

    while szam <= 156:
        print(str(szam) + "_", end="")
        szam += 4
    print(160)








