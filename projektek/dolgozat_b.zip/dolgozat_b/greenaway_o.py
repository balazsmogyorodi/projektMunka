class Film:
    def __init__(self, cim, ev):
        self.cim = cim
        self.ev = int(ev)
