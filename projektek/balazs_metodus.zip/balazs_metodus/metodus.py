def bekero():
    szam = int(input("Kérek egy számot 0 és 50 között! "))
    return szam

def SzamErtek():
    szam = bekero()
    while szam < 0 or szam > 50:
        szam = bekero()
    return szam



