import elagazas
import sorozat
import greenaway_o


#elagazas.elagazs()
#sorozat.sorozat()


file1 = open('greenaway.txt', 'r', encoding="utf-8")
file1.readline()
lines = file1.readlines()
file1.close()

filmek = []
for line in lines:
    components = line.split("-")
    filmek.append(greenaway_o.Film(components[0], components[1]))

tab = "     "
print(f"III/b.\n{tab}A filmek száma: {len(filmek)}")



index = 0
keresett = "$"
for film in filmek:
    hossz = 0
    betu = []
    while hossz < len(film.cim):
        betu.append(film.cim[hossz])
        hossz += 1
        if betu[len(betu)-1] == "$":
            index += 1
print(f"III/d.\n{tab}A kedvenc filmek száma: {index}")

filmCim = []
for line in lines:
    components = line.split("-")
    filmCim.append(components[0])



index = 0
keresett = "Víz"
for film in filmCim:
    hossz = 0
    szavak = []
    while hossz < len(film):
        elvalaszto = film.split(" ")
        szavak.append(elvalaszto)
        hossz += 1
        if "Víz" == elvalaszto[0]:
            index += 1
    print(elvalaszto)
    print(index)











