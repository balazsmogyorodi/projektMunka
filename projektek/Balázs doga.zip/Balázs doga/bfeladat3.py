import math


def negyediFeladat():
    szam = float(input("Kérek egy egész számot! "))
    if szam % 1 == 0:
        osszeg = math.radians(szam)
        print("Radián értéke:",str( osszeg))
    else:
        print("ERROR")



def otodikFeladat():

    szam = 100
    while szam > -100:
        print(str(szam) + ",", end="")
        szam -= 1
    print(-100)






