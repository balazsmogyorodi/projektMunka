import metodus

def primszam():
    szam = metodus.SzamErtek()
    if szam == 2:
        print(str(szam), "Ez prímszám.")
    elif szam == 0 or szam == 1:
        print(str(szam), "Ez nem prímszám.")
    else:
        i = 2
        while i < szam:
            if szam % i == 0:
                print(str(szam), "Ez nem prímszám.")
                quit()
            i = i + 1
        print(str(szam), "Ez prímszám.")




