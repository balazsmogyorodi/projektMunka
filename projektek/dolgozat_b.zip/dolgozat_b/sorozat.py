def sorozat():
    def feladatSzam_a():
        print("II/a.")

    def feladatSzam_b():
        print("II/b.")

    def tabosito():
        tab = "     "
        print(tab, end="")

    def listazo():
        lista = []
        szam = 100
        max = 200
        while szam < max:
            if szam % 13 == 0 :
                lista.append(szam)
            szam += 1
        return lista

    def kiiras():
        lista = listazo()
        index = 0
        tabosito()
        while index < len(lista) - 1:
            print(lista[index], end=",")
            index += 1
        print(lista[index])

    def osszesites():
        lista = listazo()
        index = 0
        osszeg = 0
        while index < len(lista):
            osszeg += lista[index]
            index += 1
        return osszeg

    def szamlalo():
        lista = listazo()
        index = 0
        hanyadik = 0
        while index < len(lista):
            hanyadik += 1
            index += 1
        return hanyadik


    def atlag ():
        osszeg = osszesites()
        amennyi = szamlalo()
        atlaga = osszeg / amennyi
        tabosito()
        szoveg = print(f"A számok átlaga: {round(atlaga)}")
        return atlaga

    def fajlIras():
        szoveg = atlag()
        beFajl = open("atlag.txt","w", encoding="utf-8")
        beFajl.write(f"A számok átlaga: {round(szoveg)}")
        beFajl.close()



    feladatSzam_a()
    kiiras()
    feladatSzam_b()
    fajlIras()

