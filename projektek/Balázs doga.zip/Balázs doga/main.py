import doga
import doga2
import bfeladat1
import bfeladat2
import bfeladat3


#doga.elsoFeladat()
#doga.masodikFeladat()
#doga2.harmadikFeladat()
#doga2.negyedikFeladat()
#doga2.otodikFeladat()


#bfeladat1.elso()
#bfeladat1.masodik()
bfeladat2.harmadikfor()
bfeladat2.harmadikwhile()
#bfeladat3.negyediFeladat()
#bfeladat3.otodikFeladat()

