import math


def elso():
    n = 1
    print("A cillag számok első 15 eleme:", end=" ")
    while n <= 14:
        osszeg = int(6 * pow(n, 2)-6 * n + 1)
        print(str(osszeg) + ", ", end="")
        n += 1
    print(1261)
    print("")
    print("")



def masodik ():

    jegy = "Q"

    if jegy == "A":
        print("Nemzetközi Csarnok, World Conservation Forum 2021")
    elif jegy == "B" or jegy == "E":
        print("Kereskedelmi Csarnok ")
    elif jegy == "C":
        print("Konferencia-központ ")
    elif jegy == "D":
        print("Hal, Víz és Ember")
    elif jegy == "F":
        print("Hagyományos Vadászati Módok Csarnoka")
    elif jegy == "G":
        print("Hazai és nemzetközi Trófeakiállítás, 12. Nyílt Európai Taxiderma-bajnokság, Vadászat 21.században kiállítás")
    elif jegy == "H":
        print("Központi Magyar Kiállítás")
    else:
        print("HIBA: Adjon meg egy betűt A-H-ig!")


