import math


def harmadikFeladat():

    szam = 1
    for szam in range(0, 51, 2):
        print(szam, "", end="")
    print("")

def negyedikFeladat():
    fok = float(input("Kérlek adj egy fok értéket: "))
    if fok % 1 == 0:
        eredmeny = int(math.sin(fok))
        print("Szinusz értéke: " + str(eredmeny) + ".")
    else:
        print("HIBA: Nem egész szám!")

def otodikFeladat():
    szam = 1
    for szam in range (25, -60, -1):
        print(str(szam) + "; ", end="")
    print(-60, end="")


