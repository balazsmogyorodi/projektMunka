def feladat4 ():
    kiFajl = open("KariVers.txt", "a", encoding="utf-8")
    kiFajl.write("\n\nTiszta öröm tüze átég\na szemeken, a harangjáték\nszól, éjféli üzenet:\nKis Jézuska született!")
    kiFajl.close()




