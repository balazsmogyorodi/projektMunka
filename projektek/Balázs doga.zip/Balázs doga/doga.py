import math

def elsoFeladat():
    k = 1
    print("A 10 legkisebb Carol-szám: ", end="")
    ciklusValtozo = k
    while ciklusValtozo <= 9:
        carol = int(math.pow(math.pow(2, ciklusValtozo) - 1, 2) - 2)
        print(str(carol) + "; ", end=" ")
        ciklusValtozo += 1
    carol = int(math.pow(math.pow(2, 10) - 1, 2) - 2)
    print(str(carol))
    print(int(math.pow(2, 3)))

def masodikFeladat():
    jegy = "VIP"



    if jegy == "VIP":
        print("Elfoglalható helyek: ", end="")
        szektor = "A"
        for szek in range(1, 11, 1):
            print(szektor + str(szek) + ", ", end="")
        print(szektor + "11")
    elif jegy == "Kiemelt vendég":
        print("Elfoglalható helyek: ", end="")
        szektor = "B"
        for szek in range(3, 9, 1):
            print(szektor + str(szek) + ",", end="")
        print(szektor + "9")
    elif jegy == "Álló":
        print("Elfoglalható helyek: ", end="")
        szektor = "E"
        for szek in range(1 ,3, 1):
            print(szektor + str(szek) + ",", end="")
        for szek in  range(10, 11, 1):
            print(szektor + str(szek) + ",", end="")
            print(szektor + "11")
    elif jegy == "Kórus":
        print("Elfoglalható helyek: ", end="")
        print("A lelátón")
    elif jegy == "Normál":
        print("Elfoglalható helyek: ", end="")
        szektor = "B"
        for szek in range(1, 3, 1):
            print(szektor + str(szek) + ", ", end="")
        for szek in range(10, 12, 1):
            print(szektor + str(szek) + ", ", end="")
        szektor = "C"
        for szek in  range(1, 12, 1):
            print(szektor + str(szek) + ", ", end="")
        szektor = "D"
        for szek in range(1, 12, 1):
            print(szektor + str(szek) + ", ", end="")
        szektor = "E"
        for szek in range(3,9,1):
            print(szektor + str(szek) + ", ", end="")
        print(szektor + "9")
    else:
        print("HIBA: Nem kezelhető jegy, keresse a biztonsági szolgálatot!")







